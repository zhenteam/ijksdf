<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>登录</title>
</head>
<script src="/js/jquery-3.1.1.min.js"></script>
<body>
    <form action="copy_add" method="post" id="xiu">
        <table border="1">
            <tr>
                <td>商品名称</td>
                <td><input type="text" name="g_name" value="<?php echo e($data->g_name); ?>"></td>
            </tr>
            <tr>
                <td>分类</td>
                <td><select name="category">
                    <option value="book">图书</option>
                    <option value="movie">电影</option>
                    <option value="mp3">音频</option>
                </select></td>
            </tr>
            <tr>
                <td>描述</td>
                <td><input type="text" name="g_desc" value="<?php echo e($data->g_desc); ?>"></td>
            </tr>
            <tr>
                <td>是否热门</td>
                <td><input type="radio" name="is_hot" value='1' <?php if($data->is_hot==1){checked;}?>>是
                <input type="radio" name="is_hot" value='0' <?php if($data->is_hot==0){checked;}?>>否</td>
            </tr>
            <tr>
                <td>上否上架</td>
                <td><input type="radio" name="is_show" value='1'>是
                <input type="radio" name="is_show" value='0'>否</td>
            </tr>
            <tr>
                <td></td>
                <td><input type="button" class="button" value="提交">
                    <input type="submit" value="mysql">
                </td>
            </tr>
        </table>
    
    </form>
</body>
</html>