<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>展示</title>
</head>
<script src="/js/jquery-3.1.1.min.js"></script>
<style>

    li{float:left;list-style:none;}
</style>
<form action="reach" method="post">
    是够热销<select name="is_hot">
        <option value="1">是</option>
        <option value="0">否</option>
    </select>
    是够上架<select name="is_show">
        <option value="1">是</option>
        <option value="0">否</option>
    </select>
    <input type="submit" value="搜索" >
</form>
<body>
    <form action="update">
        <table border="1">
            <tr>
                <td>商品ID</td>
                <td>商品名称</td>
                <td>善品分类</td>
                <td>描述</td>
                <td>是够热销</td>
                <td>是否上架</td>
                <td>操作</td>
            </tr>
            <?php foreach($data as $v){?>
            <tr>
            <input type="hidden" value="<?php echo e($v->g_id); ?>" name="id">
                <td><?php echo e($v->g_id); ?></td>
                <td><span class="first-cell" ><?php echo e($v->g_name); ?></span></td>
                <td><?php echo e($v->category); ?></td>
                <td><?php echo e($v->g_desc); ?></td>
                <td><input type="button" value="<?php echo e($v->is_hot); ?>" class="hot" oo="<?php echo e($v->g_id); ?>"></td>
                <td><input type="button" value="<?php echo e($v->is_show); ?>" class="show" oo="<?php echo e($v->g_id); ?>"></td>
                <td><input type="button" value="删除" class="del" onclick="del(<?php echo e($v->g_id); ?>)">
                <a href="copy_del?g_id=<?php echo e($v->g_id); ?>">删除</a>
                <input type="submit" value="修改" class="upd" onclick="upd(<?php echo e($v->g_id); ?>)">
                </td>
            </tr> 
            <?php }?>
        </table>
        <?php echo e($data->appends(['is_hot'=>$is_hot,'is_show'=>$is_show])->links()); ?>

    </form>
</body>
</html>
<script>
    function del(id){
        var id = id;
        $.ajax({
            url:'delete',
            type:'post',
            data:'id='+id,
            success:function(msg){
                if(msg==1){
                    alert('删除成功！');
                }
            }
        })
    }
    
</script>
<script>
    $(document).on('click','.hot',function(){
       
        var id = $(this).attr('oo');
        var va = $(this).val();
        var zz = $(this);
        $.ajax({
            url:'hot',
            type:'post',
            data:{id:id,val:va},
            success:function(msg){
                
                if(msg==1){
                    if(va==1){
                        zz.val(0);
                    }else{
                        zz.val(1);
                    }
                   
                    
                }else{
                    alert('修改失败！');
                }
            }
        })
    })

    $(document).on('click','.first-cell',function(){
	obj = $(this);	        //当前span对象
	old_val = obj.text();	//获取旧值
	
							
	//插入文本框 将旧值放入  让它的高和宽稍微比文本多一点点  而不是全部固定的
	obj.parent().html('<input type="text" value='+old_val+' style="border:1px solid blue">')
	
        //将光标获取到放到文本的尾部
	//其原理就是获得焦点后重新把自己复制粘帖一下 
	$('.first-cell input').val("").focus().val(old_val);			

    })
</script>