<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>登录</title>
</head>
<script src="/js/jquery-3.1.1.min.js"></script>
<body>

    <form action="update_do" method="post" id="xiu">
    <input type="hidden" name="g_id" value="{{$data->g_id}}">
        <table border="1">
            <tr>
                <td>商品名称</td>
                <td><input type="text" name="g_name" value="{{$data->g_name}}"></td>
            </tr>
            <tr>
                <td>分类</td>
                <td><select name="category">
                    <option value="book" <?php if($data->category=="book")?> selected {/if}>图书</option>
                    <option value="movie" <?php if($data->category=="movie")?> selected {/if}>电影</option>
                    <option value="mp3" <?php if($data->category=="mp3")?> selected {/if}>音频</option>
                </select></td>
            </tr>
            <tr>
                <td>描述</td>
                <td><input type="text" name="g_desc" value="{{$data->g_desc}}"></td>
            </tr>
            <tr>
                <td>是否热门</td>
                <td><input type="radio" name="is_hot" value='1'   @if($data->is_hot=="1") checked @endif >是
                <input type="radio" name="is_hot" value='0' @if($data->is_hot=="0") checked @endif >否</td>
            </tr>
            <tr>
                <td>上否上架</td>
                <td><input type="radio" name="is_show" value='1' @if($data->is_show=="1") checked  @endif>是
                <input type="radio" name="is_show" value='0' @if($data->is_show=="0") checked  @endif >否</td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" class="button" value="修改">
                    <input type="submit" value="mysql">
                </td>
            </tr>
        </table>
    
    </form>
</body>
</html>