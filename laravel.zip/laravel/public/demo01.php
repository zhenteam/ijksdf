<?php
    $memcache = new memcache();
    $memcache = $memcache->connect('127.0.0.1',11211);
    $key = "name";
    $value = "er";
    $time = time()+86400;

    //存
    $bol = $memcache->set($key,$value,1,$time);

    //取

    $bol1 = $memcache->get('$key');
    //数组需要序列化。。


    //替换
    $bol1 = $memcache->replace($key,"新值",1,$time)

    //删除全部
    $bol2 = $memcache->flush();

    //删除单个
    $bol1 = $memcache->delete('$key');
?>