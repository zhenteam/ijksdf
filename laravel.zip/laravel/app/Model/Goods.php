<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Goods extends Model
{
    protected $table= 'goods';
    //是否打上时间戳
    public $timestamps = false;
    //时间戳的添加，修改
    //const CREATED_AT = 'add_time';
    //const UPDATED_AT = 'upd_time';
    protected $pk = 'g_id';
    //可以被批量复制的字段
    protected $fillable = ['g_id','g_name','category','g_desc','is_hot','is_show'];
    //不能被批量赋值的
    protected $guarded = ['price'];

}
