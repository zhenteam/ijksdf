<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Good extends Model
{
    protected $table= 'shop_goods';
    //是否打上时间戳
    public $timestamps = false;
    //时间戳的添加，修改
    //const CREATED_AT = 'add_time';
    //const UPDATED_AT = 'upd_time';
    protected $pk = 'goods_id';
    //可以被批量复制的字段
    protected $fillable = ["*"];
    //不能被批量赋值的
    //protected $guarded = ['price'];
}
