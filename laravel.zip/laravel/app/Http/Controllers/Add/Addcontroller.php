<?php

namespace App\Http\Controllers\Add;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Model\Goods as Gmodel;

class Addcontroller extends Controller
{
    public function index(){
       return redirect('https://www.baidu.com/');
    }

    public function bb(){
        return view('Add.index',['id'=>'5']);
    }

    public function cc(Request $Request){
        $id = $Request->input('id');
        echo $id;
    }

    public function ff(){
        /* $sql = "INSERT INTO user SET u_name='z甄d',u_pwd=123456";

        $arr = DB::insert($sql); */

        /* $sql = "select * from user";

        $arr = DB::select($sql); */

        /* $sql = "update user set u_name='xxx' where u_id = 1";

        $arr = DB::update($sql);
        var_dump($arr); */
    }

    public function start(){
        $arr = DB::table('category')->get();
    //dump($arr);
   

        return view('Add.login',['arr'=>$arr]);
    }
    public function login(Request $Request){
        
       
        $post = $Request->input();
        //var_dump($post);
        
        $arr = DB::table('goods')->insertGetId($post);

        if($arr){
            echo 1;
        }
    }

    public function lists(){
    
          $data = DB::table('goods')->paginate(1);
          //dump($data);
          
          return view('Add.lists',['data'=>$data]);
    
    }

    public function delete(Request $Request){
        $id = $Request->input('id');
        
        $res = DB::table('goods')->where('g_id','=',$id)->delete();

        //dump($res);

        if($res){
        
            echo 1;
        }

    }

    public function update(Request $Request){
        $id = $Request->input('id');
        //dump($id);
        
        $data = Gmodel::where('g_id','=',$id)->first();
        dump($data);
        
        
        return view('Add\update',['data'=>$data]);
        

    }

    public function update_do(Request $Request){
        $id = $Request->input('g_id');
        
        $arr = $Request->input();
        //dump($arr);
    
        $res = Gmodel::where('g_id','=',$id)->update($arr);
        //dump($res);
        
        if($res){
           return redirect('lists');
        }
    }

    public function hot(Request $Request){
        $id = $Request->input('id');
        $val = $Request->input('val')==1?0:1;
        
        $res = DB::table('goods')->where('g_id','=',$id)->update(['is_hot'=>$val]);

        if($res){
            echo 1;
        }else{
            echo 0;
        }
    }

    public function copy(){
        $data = Gmodel::paginate(1);
          //dump($data);
          
          return view('Add.lists',['data'=>$data]);
    }

    public function copy_add(Request $Request){
        $arr = $Request->input();
        
        $res = Gmodel::insertGetId($arr);
        //返回值是ID啊
        //dump($res);
    }

    public function copy_del(Request $Request){
        $id = $Request->input('g_id');

        $res = Gmodel::where('g_id','=',$id)->delete();

        if($res){
            echo 1;
        }
    }

    public function reach(Request $Request){
        $is_hot = $Request->input('is_hot')==""?"":$Request->input('is_hot');
        $is_show = $Request->input('is_show')==""?"":$Request->input('is_show');

        $data = Gmodel::where('is_hot','=',$is_hot)
                    ->where('is_show','=',$is_show)
                    ->paginate(1);

        
            
        if($data){
            return view('Add.lists',['data'=>$data,'is_hot'=>$is_hot,'is_show'=>$is_show]);
        }
    }
}
