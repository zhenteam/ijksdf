<?php

namespace App\Http\Controllers\HT;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Good as Gmodel;
use App\Model\Category as Catemodel;
use App\Model\Cart as Cmodel;
use Illuminate\support\Facades\DB;

class Indexcontroller extends Controller
{
    public function Index(){

        $arr = DB::table('goods')->where('is_tell','=',1)->get();
        //dump($arr);
        
        return view('HT.index',['arr'=>$arr]);
    }
    public function Userpage(){
        return view('HT.userpage');
    }
    public function Register(){
        return view('HT.register');
    }
    public function Registerdo(Request $Request){
        $arr = $Request->input();
        //dump($arr);
        // if(!$arr['rule']){
        //     $data = [
        //         'status'=>4,
        //         'msg'=>"验证码不得为空！"
        //     ];
        //     return $data;
        // }
        /* if($arr['u_pwd']!=$arr['u_conpwd']){
            $data = [
                'status'=>0,
                'msg'=>'密码不一致!'
            ];
            return $data;
        }; */
        //验证唯一性''
        /* $test = DB::table('user')->where('u_name','=',$arr['tel'])->first();
        //dump($test);
       if($test){
        $data = [
            'status'=>1,
            'msg'=>'账号存在，请重新输入!'
        ];
        return $data;
       } */
       $n_time = time();
       //预存的判断验证码及其状态
       $pan = DB::table('prestore')->select()->where('rule',$arr['rule'])->where("limittime",">",$n_time)->where("tel",$arr['tel'])->where('status',1)->first();
       //var_dump($pan);
       
       if($pan){
                $arr['u_pwd']=md5( $arr['u_pwd']);
                unset($arr['rule']);
                $res = DB::table('user')->insertGetId($arr);
                //dump($res);
                if($res){
                    //session(['u_name'=>$res->u_name,'u_id'=>$res->u_id]);
                
                    $data = [
                        'status'=>3,
                        'msg'=>'注册成功!'
                    ];
                    return $data;
                }else{
                    $data = [
                        'status'=>2,
                        'msg'=>'注册失败!'
                    ];
                    return $data;
                }
            }else{

                $data = [
                    'status'=>0,
                    'msg'=>'验证码错误!'
                ];
                return $data;
       }


       
        
    }
    public function Login(){
        return view('HT.login');
    }
    public function Logindo(Request $Request){
        $u_name = $Request->input('tel');
        $u_pwd = $Request->input('u_pwd');
//dump($u_name);

        $arr = DB::table('user')->where('tel','=',$u_name)->first();
        
        //dump($arr);
        if($arr->u_pwd ==md5($u_pwd)){
            session(['user'=>$arr->u_id]);
           $data= [
               'status'=>1,
               'msg'=>'登陆成功！'
           ];
           return $data;
        }else{
            $data= [
                'status'=>0,
                'msg'=>'登陆失败！'
            ];
            return $data;
        }
    }

    //跳到下一步页面
    public function Regauth(Request $Request){
        $tel = $Request->input('tel');
        $u_pwd = $Request->input('u_pwd');

        return view('HT.regauth',['tel'=>$tel,'u_pwd'=>$u_pwd]);
    }

    //触发的短信验证方法
    public function T1(Request $Request){
        $obj = new \send();
        $arr = $Request->input();
        $tel = $Request->input('tel');
        $num = rand(1000,9999);
        $arr['rule'] = $num;
       
        $arr['limittime']=time()+60;
         //dump($arr);
        unset($arr['u_pwd']);
        $res = DB::table('prestore')->insert($arr);
        //dump($res);
        
        if($res){
            //$obj->show($tel,$num);
        }else{
            $data=[
                'status'=>99,
                'msg'=>"暂时不可用"
            ];

            return $data;
        }
        
    }

    //流加载
    public function Toload(Request $Request){
        $now_page = $Request->input('page');
        $pageNum = 2;
        $start = ($now_page-1)*$pageNum;
       $arr =  DB::table('goods')->offset($start)->limit($pageNum)->paginate($pageNum);
        //总页码
       $count = $arr->lastPage();
        //当前页码
        //var_dump($count);
        $info = view('HT.copy',['arr'=>$arr]);
        $content = response($info)->getContent();
        
        $data=[
            'tolpage'=>$count,
            'info'=>$content
        ];
        return $data;
    }
    //所有商品展示
    public function Allshops(){
        $arr = Gmodel::where('is_on_sale',1)->paginate(2);

        $arrcate = Catemodel::where('parent_id',0)->orderBy('add_time','desc')->select()->get('cate_id,cate_name');
        
        return view('HT.allshops',['arr'=>$arr,'arrcate'=>$arrcate]);
    }

    //所有商品滚加载
    public function Allshop(Request $Request){
        $now_page = $Request->input('page');
        $cat_id =$Request->input('cat_id');
        $pageNum = 2;
        $start = ($now_page-1)*$pageNum;

        if($cat_id){
            
        $arrcate = Catemodel::where('parent_id',$cat_id)->select()->get();
        //var_dump($arrcate);
        $arrs = $this->getSoncate($arrcate,$cat_id); 
        array_push($arrs,$cat_id);
        
        //$goods = Gmodel::whereIn('cat_id',$arr)->paginate(2);
            $arr = Gmodel::whereIn('cat_id',$arrs)->offset($start)->limit($pageNum)->paginate($pageNum);
        }else{
            $arr = Gmodel::offset($start)->limit($pageNum)->paginate($pageNum);
        }
        
        
        $count = $arr->lastPage();
        $num = ceil($count/$pageNum);
        $info = view('HT.copyall',['arr'=>$arr]); 
        $content = response($info)->getContent();

        //$arrcate = Catemodel::where('parent_id',0)->orderBy('add_time','desc')->select();

        $data=[
            'tolpage'=>$num,
            'info'=>$content,
            'cate_id'=> $cat_id,
        ];
        
        
        
        return $data;
        
         
        
       
        
    }
   
    //递归无限极ID
    function getSoncate($data,$parent_id){
        static $tempData = [];
        if($data){
            foreach($data as $k=>$v){
                if($v['parent_id']==$parent_id){
                    $tempData[]=$v['cate_id'];
                   
                    $this->getSoncate($data,$v['cate_id']);
                }
            }
        }
        return $tempData;
    }

    public  function Catshop(Request $Request){
        $cat_id = $Request->input('cat_id');
        $now_page = $Request->input('page');
        $pageNum = 2;
        $start = ($now_page-1)*$pageNum;
        //var_dump($cat_id);
        $arrcate = Catemodel::where('parent_id',$cat_id)->select()->get();
        //var_dump($arrcate);
        $arr = $this->getSoncate($arrcate,$cat_id); 
        array_push($arr,$cat_id);
        
        //$goods = Gmodel::whereIn('cat_id',$arr)->paginate(2);
        $goods = Gmodel::whereIn('cat_id',$arr)->offset($start)->limit($pageNum)->paginate($pageNum);
        //var_dump($goods);
        $count = $goods->lastPage();
        $num = ceil($count/$pageNum);
        $info = view('HT.copyall',['arr'=>$goods]); 
     
        $content = response($info)->getContent();
        $data=[
            'tolpage'=>$num,
            'info'=>$content,
            'cate_id'=> $cat_id,
            'status'=>100
        ];
        
        
        
        return $data;
    }

    public function Product(Request $Request){
        $goods_id = $Request->input('goods_id');
        $arr = Gmodel::where('goods_id',$goods_id)->get();
        //var_dump($arr);
        return view('HT.product',['arr'=>$arr]);
    }

 //运算法连脑子
   public function xxx(){
       $arr =[
           ['id'=>1,"name"=>'lisi','age'=>50],
           ['id'=>2,"name"=>'lisi','age'=>20],
           ['id'=>3,"name"=>'lisi','age'=>40],
           ['id'=>4,"name"=>'lisi','age'=>10],
           ['id'=>5,"name"=>'lisi','age'=>8]
       ];
       
       foreach($arr as $k=>$v){
            $arr1[$v['age']]= $v;
            $arr2[]=$v['age'];
       }

       sort($arr2);

       foreach($arr2 as $val){
            $arr3[]= $arr1[$val];
       }

       var_dump($arr3);
   }

   //购物车开始

   public function Shopcart(Request $Request){
    $goods_id = $Request->input('goods_id');
    $num = $Request->input('num');
    $u_id = $Request->session()->get('user');
    //var_dump($u_id);
    
    //var_dump($goods_id);
        if($goods_id){

            if($u_id){

                $good = Gmodel::where('goods_id',$goods_id)->first();
                if($good){

                        if($good['is_on_sale']==1){

                            if($num<$good->goods_number){

                                $goods = Cmodel::where('u_id',$u_id)->where('goods_id',$goods_id)->first();
                                if($goods){
                                    $nnum = $goods->shopnum + $num;
                                    $date = [
                                        
                                       
                                        'shopnum'=>$nnum,
                                       
                                        'creattime'=>time()
                                    
                                ];
                                $res = Cmodel::where('u_id',$u_id)->where('goods_id',$goods_id)->update($date);
                                if($res){
                                    $data=[
                                        'num'=>$nnum,
                                        'status'=>666,
                                        'msg'=>"添加购物车成功!"
                                    ];
                                    return $data;
                                }else{
                                    $data=[
                                        'status'=>444,
                                        'msg'=>"添加购物车失败!"
                                    ];
                                    return $data;
                                
                                }
                                }else{
                                    $date = [
                                        'goods_id'=>$goods_id,
                                        'u_id'=>$u_id,
                                        'shopnum'=>$num,
                                        'status'=>1,
                                        'creattime'=>time()
                                    
                                ];
                                $res = Cmodel::insert($date);
                                if($res){
                                    $data=[
                                        'num'=>$num,
                                        'status'=>666,
                                        'msg'=>"添加购物车成功!"
                                    ];
                                    return $data;
                                }else{
                                    $data=[
                                        'status'=>444,
                                        'msg'=>"添加购物车失败!"
                                    ];
                                    return $data;
                                
                                }
                                }
                                
                                
                            }else{
                                $data=[
                                    'status'=>4,
                                    'msg'=>"库存不足!"
                                ];
                                return $data;
                            }
                        }else{
                            $data=[
                                'status'=>3,
                                'msg'=>"此商品为开售!"
                            ];
                            return $data;
                        }
                }else{
                    $data=[
                        'status'=>2,
                        'msg'=>"无此商品!"
                    ];
                    return $data;
                    
                }
            }else{
                $data=[
                    'status'=>1,
                    'msg'=>"未登录!"
                ];
                return $data;
            }

        }else{
            $data=[
                'status'=>0,
                'msg'=>"参数未接受!"
            ];
            return $data;
        }
   }
//购物车
   public function Carts(Request $Request){
    $u_id = $Request->session()->get('user');
    $carr = Cmodel::where('u_id',$u_id)->get()->toArray();
    $arr = array_column($carr,'goods_id');
    
    $xiu = Gmodel::where('is_hot',1)->paginate(4);
    $arr = Cmodel::where('is_null',1)
                ->where('u_id',$u_id)
                ->where('status',1)
                ->join('shop_goods', 'shop_cart.goods_id', '=', 'shop_goods.goods_id')
                ->get();
    //var_dump($arr);
    
       return view('HT.shopcart',['arr'=>$arr,'xiu'=>$xiu]);
   }

//购物车内操作
public function Upnum(Request $Request){
    $u_id = $Request->session()->get('user');
    $goods_id = $Request->input('goods_id');
    $buynum = $Request->input('buynum');
    
    
    $res = Cmodel::where('u_id',$u_id)->where('goods_id',$goods_id)->update(['shopnum'=>$buynum]);
    var_dump($res);
    if($res){
        $data=[
            'status'=>666,
            
        ];
        return $data;
    }
}

//购物车内单批删
public function Zdel(Request $Request){
    $u_id = $Request->session()->get('user');
    $goods_id = is_array($Request->input('goods_id'))?$Request->input('goods_id'):[$Request->input('goods_id')];
    
    
    $res = Cmodel::where('u_id',$u_id)->whereIn('goods_id',$goods_id)->update(['is_null'=>0]);
    if($res){
        $data=[
            'status'=>666,
            'msg'=>"删除成功！"
        ];
        return $data;
    }else{
        $data=[
            'status'=>0,
            'msg'=>"删除失败！"
        ];
        return $data;
    }

}

//订单开始,页面
public function Order(Request $Request){
    $u_id = $Request->session()->get('user');

    $goods_id = is_array($Request->input('goods_id'))?$Request->input('goods_id'):[$Request->input('goods_id')];
    //var_dump($goods_id);
    
    $arrgoods=[];
    $goodsval=[];
    //验证库存
    if($u_id){
        $goodsnum = Cmodel::whereIn('goods_id',$goods_id)->where('u_id',$u_id)->select(['goods_id','shopnum'])->get();

        foreach($goodsnum as $k=>$v){
            $arrgoods[$v->goods_id]=$v->shopnum;
        }

        $res = true;
        foreach($arrgoods as  $k1=>$v1){
            $info = Gmodel::select()->where('goods_id',$k1)->first();
            $goodsval[] = $v1*$info->shop_price;
            if($v1 > $info['goods_number']){
                //总金额
                
                $res = false;
            }
        }
        
        if(!$res){
            $data = [
                'status'=>0,
                'msg'=>"库存不足"
            ];

            return $data;
        }

        //添加订单表
        //处理订单号
        $order_no  = date('YmdHis',time()).rand(1000,9999);
        //总金额数值相加
        $goodsval = array_sum($goodsval);
        //var_dump($goodsval);
       
        $data=[
            'order_no'=>$order_no,
            'u_id'=>$u_id,
            'order_amount'=>$goodsval,
            'order_pay_type'=>1,
            "pay_status"=>1,
            "pay_way"=>1,
            "status"=>1,
            'ctime'=>time()
        ];
        $orderbol = DB::table("order")->insertGetId($data);
        //var_dump($orderbol);
        //修改购物车状态

        Cmodel::whereIn("goods_id", $goods_id)->where('u_id',$u_id)->update(['status'=>2]);

        //订单详情表
        $res = $this->order_more($order_no,$u_id,$goods_id,$orderbol);
        //var_dump($res);
        if($orderbol && $res){
            $datav=[
                'status'=>666,
                'msg'=>"订单生成成功"
            ];
            return $datav;
        }else{
            $datav=[
                'status'=>555,
                'msg'=>"订单生成失败"
            ];
            return $datav;
        }
    }
    
}
 
public function Order_more($order_no,$u_id,$goods_id,$orderbol){
    $data = [
        "order_no"=>$order_no,
        'user_id'=>$u_id,
        'order_id'=>$orderbol
    ];
    $arrgoods = Cmodel::whereIn('shop_goods.goods_id',$goods_id)
                        ->where('u_id',$u_id)
                        ->join('shop_goods','shop_cart.goods_id','=','shop_goods.goods_id')
                        ->select(['shop_goods.goods_id','goods_name','shopnum','shop_price'])
                        ->get();
    //var_dump($arrgoods);
    foreach($arrgoods as $k=>$v){
        $data['goods_id']=$v->goods_id;
        $data['buy_number']=$v->shopnum;
        $data['goods_name']=$v->goods_name;
        $data['goods_price']=$v->shop_price;
       $res =  DB::table('shop_order_detail')->insert($data);
    } 
   return $res;
    
}
//订单页面
public function Orderdo(Request $Request){
    $u_id = $Request->session()->get('user');
    $arrgoods = DB::table('shop_order_detail')->where('user_id',$u_id)->select(['goods_name','goods_price','buy_number','order_no'])->get();

    return view('HT.payment',['arr'=>$arrgoods]);
}

//判断选择是否添加地址或者
public function Xu_address(Request $Request){
    $u_id = $Request->session()->get('user');
    $order_no = $Request->input('order_no');
    //var_dump($order_no);
  
    if(!$u_id){
        $data=[
            'status'=>0,
            'msg'=>"未登录"
        ];
        return $data;
    }
    /* $arr = DB::table("user_address")->where('u_id',$u_id)->select()->get();
    if(!$arr){
        $data=[
            'status'=>1,
            'msg'=>"无地址"
        ];
        return $data;
    } */
    $arr1 = DB::table("user_address")->where('u_id',$u_id)->where('is_use',1)->first();
    if(!$arr1){
        $data=[
            'status'=>2,
            'msg'=>"无地址"
        ];
        return $data;
    }else{
        //开始添加关联表单
        $data=[
            'order_no'=>$order_no,
            'u_id'=>$u_id,
            'order_receive_name'=>$arr1->ua_name,
            'receive_phone'=>$arr1->ua_phone,
            'province_id'=>0,
            'city_id'=>0,
            
            'receive_address'=>$arr1->address,
            'post_code'=>000000,
            
        ];
        $res = DB::table('shop_order_address')->insert($data);
        //var_dump($res);
        if($res){
            $date=[
                'status'=>666,
                'msg'=>"完活"
            ];
            return $date;
        }
    }

}
//跳转页面选择
public function Addadd(){
    return view('HT.writeaddr');
} 
public function adddo(Request $Request){
    $u_id = $Request->session()->get('user');
    $arr = DB::table('user_address')->where('is_null',1)->where('u_id',$u_id)->select()->get();
    return view('HT.address',['arr'=>$arr]);
}

//存入地址
public function Cr_address(Request $Request){
    $u_id = $Request->session()->get('user');
    $data = $Request->input();
    $data['u_id']=$u_id;
    if($data['is_use']=="on"){
        $data['is_use']=1;
    }else{
        $data['is_use']=0;
    }
    //var_dump($data);
    
  
   $res =  DB::table('user_address')->insert($data);
    //var_dump($res);
    if($res){
        $date = [
            'status'=>666,
            'msg'=>"添加成功！"
        ];
        return $date;
    }else{
        $date = [
            'status'=>5,
            'msg'=>"添加失败！"
        ];
        return $date;
    }
}

//删除地址
public function Deladd(Request $Request){
    $u_id = $Request->session()->get('user');
    $ua_id = $Request->input('ua_id');
    $res = DB::table("user_address")->where('ua_id',$ua_id)->update(['is_null'=>2]);
    if($res){
        $data=[
            'status'=>666,
            'msg'=>"删除成功！"
        ];
        return $data;
    }
}

//修改地址
public  function Updadd(Request $Request){
    $u_id = $Request->session()->get('user');
    $ua_id = $Request->input('ua_id');
    //var_dump($ua_id);
    $arr = DB::table("user_address")->where('ua_id',$ua_id)->get();
    return view('HT.updadd',["arr"=>$arr]);
}
//修改执行
public function Updadddo(Request $Request){
    $u_id = $Request->session()->get('user');
    $ua_id = $Request->input('ua_id');
    $data = $Request->input();
    $res = DB::table("user_address")->where('ua_id',$ua_id)->update($data);
    if($res){
        $data=[
            'status'=>666,
            'msg'=>"修改成功！"
        ];
        return $data;
    }


}
//订单页面
public  function Userprofile(Request $Request){
    $u_id = $Request->session()->get('user');
    $arr = DB::table("shop_order_detail")->where('user_id',$u_id)->get();
    return view('HT.userprofile',['arr'=>$arr]);
}
}
