<?php

namespace App\Http\Middleware;

use Closure;

class Goods
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //只能在return上面填写过滤方法
        //过滤作用
        return $next($request);
    }
}
