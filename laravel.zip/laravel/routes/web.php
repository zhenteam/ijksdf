<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('index','HT\Indexcontroller@Index');
Route::get('userpage','HT\Indexcontroller@Userpage');
Route::get('register','HT\Indexcontroller@Register');
Route::post('registerdo','HT\Indexcontroller@Registerdo');
Route::get('login','HT\Indexcontroller@Login');
Route::post('logindo','HT\Indexcontroller@Logindo');
Route::any('regauth','HT\Indexcontroller@Regauth');
Route::post('t1','HT\Indexcontroller@T1');
Route::any('prestore','HT\Indexcontroller@Prestore');
Route::any('toload','HT\Indexcontroller@Toload');
Route::any('allshops','HT\Indexcontroller@Allshops');
Route::any('allshop','HT\Indexcontroller@Allshop');
Route::any('catshop','HT\Indexcontroller@Catshop');
Route::any('product','HT\Indexcontroller@Product');
Route::any('shopcart','HT\Indexcontroller@Shopcart');
Route::any('carts','HT\Indexcontroller@Carts');
Route::any('upnum','HT\Indexcontroller@Upnum');
Route::any('zdel','HT\Indexcontroller@Zdel');
Route::any('order','HT\Indexcontroller@Order');
Route::any('orderdo','HT\Indexcontroller@Orderdo');
Route::any('addadd','HT\Indexcontroller@Addadd');
Route::any('adddo','HT\Indexcontroller@Adddo');
Route::any('xu_address','HT\Indexcontroller@Xu_address');
Route::any('cr_address','HT\Indexcontroller@Cr_address');
Route::any('deladd','HT\Indexcontroller@Deladd');
Route::any('updadd','HT\Indexcontroller@Updadd');
Route::any('updadddo','HT\Indexcontroller@Updadddo');
Route::any('userprofile','HT\Indexcontroller@Userprofile');


/*---开始简操-----*/
/* Route::get('aa','Add\Addcontroller@index');

Route::get('bb','Add\Addcontroller@bb');

Route::get('cc','Add\Addcontroller@cc');

Route::get('dd/{id}',function($id){
    echo $id;
})->where('id','[0-9]+');

Route::get('ee',function(){
    return view('Add.index',['id'=>'9']);
});

Route::get('ff','Add\Addcontroller@ff');

Route::get('start','Add\Addcontroller@start');

Route::post('login','Add\Addcontroller@login');
Route::any('lists','Add\Addcontroller@lists');
Route::any('delete','Add\Addcontroller@delete');
Route::any('update','Add\Addcontroller@update');
Route::any('update_do','Add\Addcontroller@update_do');
Route::any('hot','Add\Addcontroller@hot');
Route::any('copy','Add\Addcontroller@copy');
Route::any('copy_add','Add\Addcontroller@copy_add');
Route::any('copy_del','Add\Addcontroller@copy_del');
Route::any('reach','Add\Addcontroller@reach')->middleware('Goods'); */
/*--END---*/
/**
 * 测试   get
 */
/* Route::get('/aa',function(){
    #带目录的   return view('目录 . 文件名'); 官方
    #return view('目录/文件名');
    return view('test');
}); */



#访问test控制器  aaa路由 TestController控制器  test方法
/* Route::get('/aaa','TestController@test'); */




#如果想用post  表单提交  必须加token才能提交过去{{csrf_field()}}  或 @csrf
//Route::post('/a','TestController@testP');



#地址栏输啥  页面显示啥  function 后面加$
/*Route::get('/{id}',function($id){
    echo $id;
});*/




#也可以写多层  第一层固定  第二层随便写不加$  第三层....
//Route::any('/a/{id}','TestController@testL');




//Route::any('/a/{id}/{name}','TestController@testS');


//用不了
// Route::any('/user1','TestController@user1');




#表单页面展示
/* Route::get('/user',function(){
    return view('user.user');
});

Route::post('/user/userAdd','UserController@userAdd'); */